create function user_exit(customer_id integer) returns void
    language plpgsql
as
$$
begin
    update customer
    set become_offline_time= CURRENT_TIMESTAMP
    where customer_id = customer_id;
end;
$$;

alter function user_exit(integer) owner to postgres;

