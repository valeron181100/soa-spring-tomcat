create function customer_things(customer_nick character varying)
    returns TABLE(is_selling boolean, thing_id integer, think_name character varying, rarity rarities, customer_nick_name character varying, character_name character varying, price integer)
    language plpgsql
as
$$
begin
    return query select t.is_selling, t.thing_id, t.thing_name, t.rarity, cus.customer_nick_name, cha.character_name, t.price from thing t join customer cus using(customer_nick_name) join character cha using(thing_id) where t.is_selling = false and cus.customer_nick_name = customer_nick;
end;
$$;

alter function customer_things(varchar) owner to postgres;

