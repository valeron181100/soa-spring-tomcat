create function buy_thing(first_customer_nick character varying, sec_customer_nick character varying, selling_thing_id integer) returns void
    language plpgsql
as
$$
declare
    enough_money boolean;
    buyer_money integer;
    seller_money integer;
    thing_price integer;
    seller_is_null boolean = true;

begin
    select price into thing_price from thing t where t.thing_id = selling_thing_id;
    select p.customer_balance into buyer_money from customer c join paymentmethod p using(customer_nick_name) where first_customer_nick = c.customer_nick_name;
    if (buyer_money >= thing_price) then
        UPDATE thing t SET customer_nick_name = first_customer_nick, is_selling = false WHERE t.thing_id = selling_thing_id;
        UPDATE paymentmethod p SET customer_balance = (buyer_money - thing_price) WHERE p.customer_nick_name = first_customer_nick;
        insert into transaction(first_customer_nick , sec_customer_nick , first_thing_id, sec_thing_id, platform_id, transaction_type  ) values(first_customer_nick, sec_customer_nick, selling_thing_id, null, 1, 'Sale');
        select c.customer_nick_name into seller_is_null from customer c where c.customer_nick_name = sec_customer_nick and c.customer_nick_name is null;
        if (seller_is_null = true) then
            select p.customer_balance into seller_money from customer c join paymentmethod p using(customer_nick_name) where sec_customer_nick = c.customer_nick_name;
            UPDATE paymentmethod p SET customer_balance = (seller_money + thing_price) WHERE p.customer_nick_name = sec_customer_nick;
        end if;
    end if;
end;
$$;

alter function buy_thing(varchar, varchar, integer) owner to postgres;

