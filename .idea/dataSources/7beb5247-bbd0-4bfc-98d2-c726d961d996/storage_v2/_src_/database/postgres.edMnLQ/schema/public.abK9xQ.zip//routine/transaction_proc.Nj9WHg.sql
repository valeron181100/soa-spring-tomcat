create function transaction_proc() returns trigger
    language plpgsql
as
$$
declare
    firstUserTransact INT;
    firstUserRatingID INT;
    secUserTransact INT;
    secUserRatingID INT;

begin
    select rating_id into firstUserRatingID  from customer where customer_nick_name = new.first_customer_nick;
    select rating_id into secUserRatingID from customer where customer_nick_name = new.sec_customer_nick;
    select transactions_num into firstUserTransact from rating
    where rating_id = firstUserRatingID;

    select transactions_num into secUserTransact from rating
    where rating_id = secUserRatingID;
    update rating
    set transactions_num = (firstUserTransact + 1)
    where rating_id = firstUserRatingID;

    update rating
    set transactions_num = (secUserTransact + 1)
    where rating_id = secUserRatingID;
    return new;
end;
$$;

alter function transaction_proc() owner to postgres;

