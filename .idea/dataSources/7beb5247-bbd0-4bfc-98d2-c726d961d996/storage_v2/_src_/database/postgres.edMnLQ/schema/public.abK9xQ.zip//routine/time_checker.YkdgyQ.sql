create function time_checker() returns trigger
    language plpgsql
as
$$
begin
    NEW."Списано" = (NEW."Времяокончаниясрока" >= CURRENT_TIMESTAMP);
    RETURN NEW;
end;
$$;

alter function time_checker() owner to postgres;

