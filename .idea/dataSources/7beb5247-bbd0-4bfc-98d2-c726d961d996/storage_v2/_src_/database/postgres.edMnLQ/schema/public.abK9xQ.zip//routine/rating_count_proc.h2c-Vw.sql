create function rating_count_proc() returns trigger
    language plpgsql
as
$$
begin
    new.rating_num = new.rating_num + (new.transactions_num * 10 - new.offense_num * 3);
    return new;
end;
$$;

alter function rating_count_proc() owner to postgres;

