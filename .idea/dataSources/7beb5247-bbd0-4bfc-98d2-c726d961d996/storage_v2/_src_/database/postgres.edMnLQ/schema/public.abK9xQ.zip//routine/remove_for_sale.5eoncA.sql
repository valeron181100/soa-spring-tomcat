create function remove_for_sale(selling_thing_id integer) returns void
    language plpgsql
as
$$
begin
    UPDATE thing t SET is_selling = false WHERE t.id = selling_thing_id;
end;
$$;

alter function remove_for_sale(integer) owner to postgres;

