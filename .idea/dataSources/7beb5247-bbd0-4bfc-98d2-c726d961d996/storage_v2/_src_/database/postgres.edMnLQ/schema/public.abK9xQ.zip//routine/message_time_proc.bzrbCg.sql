create function message_time_proc() returns trigger
    language plpgsql
as
$$
begin
    new.send_time = CURRENT_TIMESTAMP;
    return new;
end;
$$;

alter function message_time_proc() owner to postgres;

