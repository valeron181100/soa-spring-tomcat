create function message_info_sendler_recipient(originator_nick character varying, addressee_nick character varying)
    returns TABLE(sender_nick character varying, recipient_nick character varying, content character varying, send_time timestamp without time zone)
    language plpgsql
as
$$
begin
    return query select m.sender_nick, m.recipient_nick, m.content, m.send_time from message m where ((originator_nick = m.sender_nick) and (addressee_nick = m.recipient_nick)) or ((addressee_nick = m.sender_nick) and (originator_nick = m.recipient_nick));
end;
$$;

alter function message_info_sendler_recipient(varchar, varchar) owner to postgres;

